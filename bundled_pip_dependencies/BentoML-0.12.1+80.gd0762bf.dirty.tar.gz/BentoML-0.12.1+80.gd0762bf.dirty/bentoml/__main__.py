if __name__ == '__main__':
    from bentoml.cli import create_bentoml_cli

    create_bentoml_cli()()
